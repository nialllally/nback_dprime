%3-back D-prime function - need to pass a number of trials

function [parameters, results]=D3_back(trials,hitpc)
rand('state',sum(100*clock));%set random number generator
% format('shortG')

%% variable options
parameters.trials=trials; %how many letter presentations? Must be a multiple of  letters
parameters.hitnum=(trials/100)*hitpc; %how many hits
parameters.letters={'q','w','y','z','m'};
parameters.ITI=1500;
parameters.stim_dur=500; %ms
parameters.resp_button=[6, 8];

%% Cogent start Not needed, already started...
% config_display(1,1)
% config_keyboard
% start_cogent;
btime=(parameters.trials*2)/60;
%% task block loop
for k1=3:3
    
    %% task start
    totlets=repmat(parameters.letters,1,(parameters.trials/length(parameters.letters)));
    looptracker=0;
    Proceed=0;
    
    while Proceed==0
        r=randperm(length(totlets));
        parameters.numorder=totlets(r)';
        results.shudaprsd(1:parameters.trials,1)=0;
        parameters.trial_letter=parameters.numorder;
        for j3=k1+1:parameters.trials  %
            if parameters.trial_letter{j3,1}==parameters.trial_letter{j3-k1,1}
                results.shudaprsd(j3,1)=1; %shows where the correct answers were
            else
                results.shudaprsd(j3,1)=0;
            end
        end
        if k1==1
            if sum(results.shudaprsd(:,1))>0
                Proceed=1;
            end
        elseif k1>1
            if sum(results.shudaprsd(:,1))>parameters.hitnum
                Proceed=0;
            elseif sum(results.shudaprsd(:,1))==parameters.hitnum
                Proceed=1;
            end
        else
            Proceed=1;
        end
        looptracker=looptracker+1;
    end
    
    %%
    results.key_press(1:parameters.trials,1)=0;
    cgfont('Arial', 30)
    cgpencol(1,1,1)
    cgfont('Arial', 20)
    cgtext(sprintf('%d minutes of %d-back!',btime,k1),0,50);
    cgtext('Hit the (H) button when...',0,25);
    cgtext(sprintf('the onscreen letter is the same as the letter %d-back.',k1),0,0);
    cgtext('i.e. when there are two letters between the same letter repeated.',0,-25);
    cgtext('e.g.  A B A C D A A ',0,-50);
    cgtext('Here, respond (H) when the 3rd A appears, otherwise press (F).',0,-75);   
    cgtext('Participant - press space to begin',0,-150);
    cgflip(0,0,0);
    waitkeydown(inf,71);
    
    %% Present the stimuli - initial fixation
    cgfont('Arial', 30)
    cgpencol(.7,.7,.7)
    cgtext('+',0,0);
    cgtext(sprintf('%d back',k1,0,150));
    results.fixation(1,1)=cgflip(0,0,0); %Need to organize these in the correct manner!!
    waituntil((results.fixation(1,1)*1000)+parameters.ITI);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for k2=1:parameters.trials%
        cgflip(0,0,0)
        cgpencol(.7,.7,.7)
        cgfont('Arial', 80)
        cgtext(parameters.numorder{k2},0,0);%puts the letter onscreen
        cgtext(sprintf('%d back',k1,0,150));
        
        clearkeys
        results.letter_onscreen(k2,1)=cgflip(0,0,0);
        
        cgfont('Arial', 20)
        waituntil((results.letter_onscreen(k2,1))*1000+parameters.stim_dur);
        cgflip(0,0,0)
        cgtext('+',0,0);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        results.stimulus_interval(k2,1)=cgflip(0,0,0);
        
        readkeys
        [k,reaction_time,n]=getkeydown([parameters.resp_button]);
        if n>0
            %results.key_press(k2,1)=1;%need to alter this
            results.key_press(k2,1)=k(1);%need to alter this
            results.RT(k2,1)=reaction_time(1)/1000-results.letter_onscreen(k2,1);
        end
        waituntil((results.stimulus_interval(k2,1))*1000+parameters.ITI);
        
        if results.key_press(k2,1)==0
            readkeys
            [k,reaction_time,n]=getkeydown([parameters.resp_button]);
            if n>0
                results.key_press(k2,1)=k(1);%need to alter this
                results.RT(k2,1)=reaction_time(1)/1000-results.letter_onscreen(k2,1);
            end
        end
    end
    %% work out performance related stuff here
    
    results.Hits=0; %detected x-back
    results.CRs=0; %correct rejection - detected incorrect letter    
    results.FAs=0; %false alarm - responded when they shouldn't have
    results.Misses=0; %a hit classified as a miss
    results.or=0;
    results.oh=0;
    
    parameters.trial_letter=parameters.numorder;
    
    for j3=k1+1:parameters.trials  %goes from either 2 or 4:
        if parameters.trial_letter{j3,1}==parameters.trial_letter{j3-k1,1}
            results.shudaprsd(j3,1)=1; %shows where the correct answers were
        else
            results.shudaprsd(j3,1)=0;
        end
    end
    for k5=1:parameters.trials%could go from the second one...
        %what about failed responses!!!! 2AFC
        %%  CRs or misses
        if results.key_press(k5,1)==6 && results.shudaprsd(k5,1)==1
            results.Misses=results.Misses+1;%6 is no detection
        elseif results.key_press(k5,1)==6 && results.shudaprsd(k5,1)==0
            results.CRs=results.CRs+1;            
            %% Hits or FAs
        elseif results.key_press(k5,1)==8 && results.shudaprsd(k5,1)==1
            results.Hits=results.Hits+1;%8 = detected
        elseif results.key_press(k5,1)==8 && results.shudaprsd(k5,1)==0
            results.FAs=results.FAs+1;
            %% ommitted responses
        elseif results.key_press(k5,1)==0 && results.shudaprsd(k5,1)==0
            results.or=results.or+1;
        elseif results.key_press(k5,1)==0 && results.shudaprsd(k5,1)==1
            results.oh=results.oh+1;
        end
    end
    
    results.HR=results.Hits/(results.Hits + results.Misses+results.oh);
    results.FAR = results.FAs/(results.FAs + results.CRs+results.or);
    results.Z_HR = norminv(results.HR);
    results.Z_FAR= norminv(results.FAR);
    %d=results.Z_HR-results.Z_FAR
    results.d=dprime(results.HR,results.FAR,results.HR+results.Misses,results.FAR+results.CRs);
    
end
end