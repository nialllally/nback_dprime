%D N-back - Day 2
%subject must respond to every stimulus
%give them a hint and say that there is only one hit
%hit=h (for present, i.e. a 3 back response is present)
%miss=f (for fail to hit)
%%
clc
clear
rand('state',sum(100*clock));%set random number generator
format bank
%% Input variables

parameters.name=input('Enter initials and age (e.g aa22)? ','s');
switch parameters.name
    case ''
        disp('No subject name entered')
        return
end
parameters.session=2;

parameters.subj_code=[date '_' parameters.name '_' num2str(parameters.session)];
subj_code=parameters.subj_code;
%% Cogent start
config_display(1,1)
config_keyboard
start_cogent;



%% tDCS
cgpencol(1,1,1) %change the text
cgfont('Arial', 20)
cgtext('Apply DCS',0,0);
cgtext('Researcher press space to begin',0,-150);
cgflip(0,0,0);
waitkeydown(inf,71);

cgtext('Respond to all letters, (H) is for hit, (F) is for fail to hit!.',0,-25);
cgtext('Respond as quickly and as accurately as possible.',0,-50);
cgtext('Responses during the fixation are permitted.',0,-75);
cgtext('Press space to continue.',0,-150);
cgflip(0,0,0);
waitkeydown(inf,71);

[parameters,results]=d3_back(300,20);% 10 minutes of tDCS
parameters.subj_code=subj_code;
save([parameters.subj_code '_DCS'],'parameters','results')
clear parameters results 
%

%% test - no DCS
cgtext('Now time for the test.',0,50);
cgtext('Payment is test performance dependent - do your best!',0,25);
cgtext('�5 bonus for performing better than yesterday!',0,25);
cgtext('Researcher press space.',0,-150);
cgflip(0,0,0);
waitkeydown(inf,71);

[parameters,results]=d3_back(300,20);%10 minutes of test
parameters.subj_code=subj_code;
save([parameters.subj_code '_Test'],'parameters','results')
clear parameters results 
%% end
stop_cogent;
clc